private function getInstagramCredentials(): array
{
    $plugin = \Plugin::getPluginById('portlets_sellx'); // Ersetze mit deiner Plugin-ID
    return [
        'username' => $plugin->getConfig('instagram_username'),
        'password' => $plugin->getConfig('instagram_password')
    ];
}

private function fetchInstagramImages(int $limit): array
{
    $scriptPath = __DIR__ . "/scripts/get_instagram_images.py";
    $credentials = $this->getInstagramCredentials();

    if (empty($credentials['username']) || empty($credentials['password'])) {
        return ['error' => '⚠️ Instagram-Zugangsdaten fehlen!'];
    }

    $command = escapeshellcmd("python3 $scriptPath '{$credentials['username']}' '{$credentials['password']}' $limit");
    $output = shell_exec($command);

    return json_decode($output, true) ?: ['error' => '⚠️ Fehler beim Abrufen der Instagram-Bilder'];
}

public function getFinalHtml(PortletInstance $instance): string
{
    $smarty = \JTL\Shop::Smarty();
    $limit = (int) $instance->getProperty('limit', 5);
    $images = $this->fetchInstagramImages($limit);

    $smarty->assign('instagramImages', $images);
    return $smarty->fetch('plugins/portlets_sellx/Portlets/InstagramFeed/InstagramFeed.tpl');
}
