$(() => {
    console.log('Kategorien geladen', opc)
})
