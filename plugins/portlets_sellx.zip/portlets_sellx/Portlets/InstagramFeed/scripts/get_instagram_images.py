import sys
import json
from instagrapi import Client

def get_latest_images(username, password, amount=5):
    """Holt die letzten `amount` Bilder eines Instagram-Profils"""
    try:
        cl = Client()
        cl.login(username, password)

        user_id = cl.user_id_from_username(username)
        medias = cl.user_medias(user_id, amount)

        image_urls = [m.thumbnail_url for m in medias if m.media_type == 1]
        print(json.dumps(image_urls))

    except Exception as e:
        print(json.dumps({"error": str(e)}))

if __name__ == "__main__":
    username = sys.argv[1]
    password = sys.argv[2]
    amount = int(sys.argv[3])
    get_latest_images(username, password, amount)
